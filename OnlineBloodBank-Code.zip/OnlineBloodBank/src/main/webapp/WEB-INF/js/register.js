
         function validatePincode() {
        	 console.log("Validate Pincode");
    	  var x, text;
    	  x = document.getElementById("pincode").value;
    	  if (isNaN(x) || x.length<6 || x.length>6) {
    	    text = "*Should be 6 digits and numerical value.";
    	    document.getElementById("pinValid").innerHTML = text;
    	    return false;
    	  }
    	  else{
    	  document.getElementById("pinValid").innerHTML ="";
    	  return true;
    	  } 
        	
         }
    	  
    	  function validateContact() {
        	  var x, text;
        	  x = document.getElementById("contact").value;
        	  if (isNaN(x) || x.length<10 || x.length>10) {
        	    text = "*Should be 10 digits and numerical value.";
        	    document.getElementById("contactValid").innerHTML = text;
        	    return false;
        	  }
        	  else{
        	  document.getElementById("contactValid").innerHTML ="";
        	  return true;
        	  }
    	  }
    	  
    	  function validateFirstName() {
        	  var x, text;
        	  x = document.getElementById("first").value;
        	  var letters = /^[A-Za-z]+$/;
        	
        	  if (x.match(letters)) {
        		  document.getElementById("firstValid").innerHTML ="";
        		  return true;
        	  }
        	  else{
        		  text = "*Should contains only alphabets.";
          	    document.getElementById("firstValid").innerHTML = text;
          	    return false;
        	  }
    	  }
    	  
    	  
    	  function validateLastName() {
        	  var x, text;
        	  x = document.getElementById("last").value;
        	  var letters = /^[A-Za-z]+$/;
        
        	  if (x.match(letters)) {
        		  document.getElementById("lastValid").innerHTML ="";
        		  return true;
        	  }
        	  else{
        		  text = "*Should contains only alphabets.";
          	    document.getElementById("lastValid").innerHTML = text;
          	    return false;
        	  }
    	  }
    	  
    	  
    	  function validateAge() {
        	  var x, text;
        	  x = document.getElementById("age").value;
        	  if (isNaN(x) || x.length<1 || x.length>3 || parseInt(x)<18 || parseInt(x)>65 ) {
        	    text = "*Should be between 18 to 65.";
        	    document.getElementById("ageValid").innerHTML = text;
        	    return false;
        	  }
        	  else{
        	  document.getElementById("ageValid").innerHTML ="";
        	  return true;
        	  }
    	  }
    	  
    	  function validateWeight() {
        	  var x, text;
        	  x = document.getElementById("weight").value;
        	  if (isNaN(x) ||  x.length>3 || parseInt(x)>150 || parseInt(x)<30) {
        	    text = "*Please enter a valid weight.";
        	    document.getElementById("weightValid").innerHTML = text;
        	    return false;
        	  }
        	  else{
        	  document.getElementById("weightValid").innerHTML ="";
        	  return true;
        	  }
    	  }
    	  
    	  
    	  function validatePassword() {
        	  var x, text;
        	  x = document.getElementById("password").value;
        	  if (x.length<8 || x.length>15) {
        	    text = "*Should be between 8 to 15 characters.";
        	    document.getElementById("passwordValid").innerHTML = text;
        	    return false;
        	  }
        	  else{
        	  document.getElementById("passwordValid").innerHTML ="";
        	  return true;
        	  }
    	  }
    	  
    	 
    	  
    	  function stateCity(value){
    			var cities={
    					Punjab:["Kharar","Patiala","Mohali","Moga","Chandigarh"],
    					Himachal:["Shimla","Dalhousie","Mandi","Manali","Dharmshala"],
    					Haryana:["Rohtak","Bhiwani","Hisar","Sonipat","Ambala"],
    					Delhi:["Pitampura","Hauz Khas","Saket","Cannaught Place"],		
    			}	
    			
    			if (value.length == 0) document.getElementById("area").innerHTML = "<option></option>";
    		    else {
    		        var catOptions = "";
    		        for (citId in cities[value]) {
    		            catOptions += "<option>" + cities[value][citId] + "</option>";
    		        }
    		        document.getElementById("area").innerHTML = catOptions;
    		    }
    			
    			}
    	  
    	
    	  
    	 