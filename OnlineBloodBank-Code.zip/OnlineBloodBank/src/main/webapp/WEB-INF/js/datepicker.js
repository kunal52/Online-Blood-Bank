function datePickerJS(){
var today = new Date();
var tomorrow=new Date();
tomorrow.setDate(today.getDate()+1);
var datetom=tomorrow.toISOString().split('T')[0];
document.getElementById("datepicker").setAttribute('min',datetom);
}