
      function validatePincode() {
    	  var x, text;
    	  x = document.getElementById("pincode").value;
    	  if (isNaN(x) || x.length<6 || x.length>6) {
    	    text = "*Should be 6 digits and numerical value";
    	    document.getElementById("pinValid").innerHTML = text;
    	  }
    	  else{
    	  document.getElementById("pinValid").innerHTML ="";
    	  }
    	}
      
     