package com.service;

import com.model.BloodDonationEntity;

public interface BloodDonationService {
	boolean addBloodDonation(BloodDonationEntity bloodDonationEntity);
}
