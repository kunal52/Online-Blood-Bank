package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.FeedbackDAO;
import com.model.FeedbackEntity;

@Service("feedbackservice")
public class FeedbackServiceImpl implements FeedbackService {

	public FeedbackServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Autowired
	FeedbackDAO feedbackDAO;
	
	@Transactional
	@Override
	public boolean saveFeedback(FeedbackEntity feedback) {
		boolean flag;
		flag=feedbackDAO.saveFeedback(feedback);
		return flag;
	}

	@Transactional
	@Override
	public List<FeedbackEntity> getFeedBackList() {
		return feedbackDAO.getFeedbackList();
	}

}
