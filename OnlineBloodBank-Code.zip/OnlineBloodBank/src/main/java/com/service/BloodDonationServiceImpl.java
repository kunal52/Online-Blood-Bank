package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.BloodDonationDAO;
import com.model.BloodDonationEntity;

@Service("blooddonationservice")
public class BloodDonationServiceImpl implements BloodDonationService {

	@Autowired
	BloodDonationDAO blooddonationdao;
	
	public BloodDonationServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Transactional
	@Override
	public boolean addBloodDonation(BloodDonationEntity bloodDonationEntity) {
		return blooddonationdao.addBloodDonation(bloodDonationEntity);
	}

}
