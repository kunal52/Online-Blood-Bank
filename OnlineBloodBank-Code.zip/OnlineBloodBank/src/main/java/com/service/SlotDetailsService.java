package com.service;


import com.model.HospitalSlotEntity;

public interface SlotDetailsService {

	boolean BookSlotRequirement(HospitalSlotEntity hospitalslotentity);
}
