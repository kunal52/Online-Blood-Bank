package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.SlotDetailsDAO;
import com.model.HospitalSlotEntity;

@Service("slotdetailsservice")
public class SlotDetailsServiceImpl implements SlotDetailsService {

	@Autowired 
	SlotDetailsDAO slotdetailsdao;
	
	public SlotDetailsServiceImpl() {
	
	}

	@Transactional
	@Override
	public boolean BookSlotRequirement(HospitalSlotEntity hospitalslotentity) {
		
		return slotdetailsdao.BookSlotRequirement(hospitalslotentity);
	}

}
