package com.service;

import java.util.List;

import com.model.BloodDonationEntity;

public interface BloodAvailibilityService {
public List<BloodDonationEntity> searchBloodAvailabilty(BloodDonationEntity blood_search); 
}
