package com.service;

import com.model.UserDetailsEntity;

public interface UserService {
	  public boolean saveUser(UserDetailsEntity user);
}
