package com.service;

import java.util.List;

import com.model.FeedbackEntity;

public interface FeedbackService {
	boolean saveFeedback(FeedbackEntity feedback);
	List<FeedbackEntity>getFeedBackList();

}
