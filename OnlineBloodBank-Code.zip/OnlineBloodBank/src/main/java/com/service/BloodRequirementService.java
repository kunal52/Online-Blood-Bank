package com.service;

import java.util.List;

import com.model.BloodRequirementEntity;

public interface BloodRequirementService {
	boolean addBloodRequirement(BloodRequirementEntity bloodRequirementEntity);
	List<BloodRequirementEntity> getBloodRequirementList();
}
