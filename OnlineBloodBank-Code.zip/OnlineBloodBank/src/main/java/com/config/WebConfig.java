package com.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com" })
public class WebConfig implements WebMvcConfigurer {
  @Override
  public void configureViewResolvers(ViewResolverRegistry registry) {
    registry.jsp().prefix("/WEB-INF/views/").suffix(".jsp");
  }

  @Override
  public void addViewControllers(ViewControllerRegistry registry) {
    registry.addViewController("/login").setViewName("login");
  }

@Override
public void addResourceHandlers(ResourceHandlerRegistry registry) {
	registry.addResourceHandler("/css/**").addResourceLocations("/WEB-INF/css/");
	registry.addResourceHandler("/availability/css/**").addResourceLocations("/WEB-INF/css/");
	registry.addResourceHandler("/donation/css/**").addResourceLocations("/WEB-INF/css/");
	registry.addResourceHandler("/requirement/css/**").addResourceLocations("/WEB-INF/css/");
	registry.addResourceHandler("/feedback/css/**").addResourceLocations("/WEB-INF/css/");
	
	registry.addResourceHandler("/js/**").addResourceLocations("/WEB-INF/js/");
	registry.addResourceHandler("/availability/js/**").addResourceLocations("/WEB-INF/js/");
	registry.addResourceHandler("/donation/js/**").addResourceLocations("/WEB-INF/js/");
	registry.addResourceHandler("/requirement/js/**").addResourceLocations("/WEB-INF/js/");
	registry.addResourceHandler("/feedback/js/**").addResourceLocations("/WEB-INF/js/");
	
	
	//WebMvcConfigurer.super.addResourceHandlers(registry);
}
  
  
  
}
