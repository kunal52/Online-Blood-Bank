package com.dao;

import com.model.UserDetailsEntity;

public interface UserDAO {
	  boolean registerUser(UserDetailsEntity user);
}
