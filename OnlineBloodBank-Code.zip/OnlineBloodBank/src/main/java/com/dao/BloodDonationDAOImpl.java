package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.BloodDonationEntity;
import com.model.BloodRequirementEntity;

@Repository("blooddonationdao")
public class BloodDonationDAOImpl implements BloodDonationDAO{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public boolean addBloodDonation(BloodDonationEntity bloodDonationEntity) {
		Session currentSession = sessionFactory.getCurrentSession();
		try
		{
			currentSession.save(bloodDonationEntity);
			
		}catch (Exception e) {
			return false;
		}
		
		removeFromRequirement(bloodDonationEntity);
		
		return true;
	}
	
	public void removeFromRequirement(BloodDonationEntity bloodDonationEntity)
	{
		Session currentSession = sessionFactory.getCurrentSession();
		Query createQuery = currentSession.createQuery("from BloodRequirementEntity bre where bre.state =:state and "
				+ "bre.pincode =:pincode and "
				+ "bre.blood_group =:blood_group and "
				+ "bre.area =:area");
		
		createQuery.setParameter("state", bloodDonationEntity.getState());
		createQuery.setParameter("pincode", bloodDonationEntity.getPincode());
		createQuery.setParameter("blood_group", bloodDonationEntity.getBlood_group());
		createQuery.setParameter("area", bloodDonationEntity.getArea());
		
		
		List<BloodRequirementEntity> list = createQuery.list();
		
		if (list.size()>0) {
			BloodRequirementEntity bloodRequirementEntity = list.get(0);
			currentSession.delete(bloodRequirementEntity);
		}
		
		
		
	}
	
	
	
	
	public BloodDonationDAOImpl() {
		// TODO Auto-generated constructor stub
	}

}
