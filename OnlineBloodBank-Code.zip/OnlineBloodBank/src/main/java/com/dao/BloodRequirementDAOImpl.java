package com.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.BloodDonationEntity;
import com.model.BloodRequirementEntity;

@Repository("bloodrequirementdao")
public class BloodRequirementDAOImpl implements BloodRequirementDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public boolean addBloodRequirement(BloodRequirementEntity bloodRequirementEntity) {
		Session currentSession = sessionFactory.getCurrentSession();
		try
		{
			currentSession.saveOrUpdate(bloodRequirementEntity);
		}catch (Exception e) {
			return false;
		}
		
		return true;
	}

	@Override
	public List<BloodRequirementEntity> bloodRequirmentList() {
		Session currentSession = sessionFactory.getCurrentSession();
		List<BloodRequirementEntity> requirementList;
			Query query= currentSession.createQuery("from BloodRequirementEntity", BloodRequirementEntity.class);
			requirementList = query.getResultList();
		return requirementList;
	}

}
