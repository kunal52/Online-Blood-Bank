package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.FeedbackEntity;

@Repository("feedbackDAO")
public class FeedbackDAOImpl implements FeedbackDAO {

	
	@Autowired
	SessionFactory sessionFactory;
	@Override
	public boolean saveFeedback(FeedbackEntity feedback) {
		try{
		sessionFactory.getCurrentSession().saveOrUpdate(feedback);
		}
		catch(Exception e){
			return false;
		}
		return true;
	}
	@Override
	public List<FeedbackEntity> getFeedbackList() {
	    Session currentSession = sessionFactory.getCurrentSession();
	    List<FeedbackEntity> list = currentSession.createQuery("from FeedbackEntity").list();
		return list;
		
	}

}
