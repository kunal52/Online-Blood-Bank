package com.dao;


import com.model.HospitalSlotEntity;

public interface SlotDetailsDAO {
	boolean BookSlotRequirement(HospitalSlotEntity hospitalslotentity);
}
