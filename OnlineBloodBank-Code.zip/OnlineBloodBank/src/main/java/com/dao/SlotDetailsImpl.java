package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.HospitalSlotEntity;

@Repository("slotdetailsdao")
public class SlotDetailsImpl implements SlotDetailsDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	public SlotDetailsImpl() {
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public boolean BookSlotRequirement(HospitalSlotEntity hospitalslotentity) {
		// TODO Auto-generated method stub
		
		
		
		Session currentSession = sessionFactory.getCurrentSession();
		
		
		Query createNamedQuery = currentSession.getNamedQuery("fetchhospitaldata");
		
		createNamedQuery.setParameter("hname", hospitalslotentity.getHospitalname());
		createNamedQuery.setParameter("city", hospitalslotentity.getCity());
		createNamedQuery.setParameter("time",hospitalslotentity.getTime());
		createNamedQuery.setParameter("date", hospitalslotentity.getDate());
		
		
		
		List<HospitalSlotEntity> resultList = createNamedQuery.getResultList();
		
		if(resultList.size()>1)
		{
			return false;
		}
		
		try
		{
			currentSession.save(hospitalslotentity);
		}catch (Exception e) {
			return false;
		}
		
		return true;
	}

}
