package com.dao;

import java.util.List;

import com.model.BloodRequirementEntity;

public interface BloodRequirementDAO {
	boolean addBloodRequirement(BloodRequirementEntity bloodRequirementEntity);
	List<BloodRequirementEntity> bloodRequirmentList();
}
