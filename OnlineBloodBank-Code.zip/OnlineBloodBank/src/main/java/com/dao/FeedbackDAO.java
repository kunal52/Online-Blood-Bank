package com.dao;

import java.util.List;

import com.model.FeedbackEntity;

public interface FeedbackDAO {

	boolean saveFeedback(FeedbackEntity feedback);
	List<FeedbackEntity>getFeedbackList();
}
