package com.dao;

import com.model.BloodDonationEntity;

public interface BloodDonationDAO {
	boolean addBloodDonation(BloodDonationEntity bloodDonationEntity);
}
