package com.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@NamedQueries
({
	@NamedQuery(name="fetchhospitaldata",query="from HospitalSlotEntity hs "
			+ "where hs.hospitalname =:hname "
			+ "and hs.city =:city "
			+ "and hs.time =:time "
			+ "and hs.date =:date")
})


@Entity(name="HospitalSlotEntity")
@Table(name="slot_booking")
public class HospitalSlotEntity {

	@Id
	@GeneratedValue(generator="UUID")
	@GenericGenerator(name="UUID", strategy="org.hibernate.id.UUIDGenerator")
	@Column(name="id")
	UUID id;
	
	@Column(name="hospital_name")
	String hospitalname;
	
	@Column(name="city")
	String city;
	
	@Column(name="date")
	String date;
	
	@Column(name="time")
	String time;
	


	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public HospitalSlotEntity(UUID id, String hospitalname, String city, String date, String time) {
		super();
		this.id = id;
		this.hospitalname = hospitalname;
		this.city = city;
		this.date = date;
		this.time = time;
	}

	public HospitalSlotEntity(String hospitalname, String city, String date, String time) {
		super();
		this.hospitalname = hospitalname;
		this.city = city;
		this.date = date;
		this.time = time;
	}

	public String getHospitalname() {
		return hospitalname;
	}

	public void setHospitalname(String hospitalname) {
		this.hospitalname = hospitalname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public HospitalSlotEntity() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "HospitalSlotEntity [id=" + id + ", hospitalname=" + hospitalname + ", city=" + city + ", date=" + date
				+ ", time=" + time + "]";
	}

	
	
}
