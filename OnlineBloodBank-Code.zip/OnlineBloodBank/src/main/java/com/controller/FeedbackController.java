package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.model.FeedbackEntity;
import com.service.FeedbackService;

@Controller
@RequestMapping("feedback")
public class FeedbackController {
	
	@Autowired
	FeedbackService feedbackService;
	
	@GetMapping("/form")  //It displays the Feedback form
	String showFeedbackForm(Model model){
		
		FeedbackEntity feedback=new FeedbackEntity();
		model.addAttribute("feedback", feedback);
		return "feedbackForm";
	}
	
	@PostMapping("/save")  //It adds the Feedback to the database
	String saveFeedbackDetails(@ModelAttribute("feedback") FeedbackEntity feedback){
		
		boolean flag;
		flag=feedbackService.saveFeedback(feedback);
		return "redirect:/home";
	}
	
	
	@GetMapping("/contact")  //It displays the Contact information of the developers of this application
	public String openContact(){
		return "contact";
	}


}
