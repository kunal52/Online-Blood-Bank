package com.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.BloodDonationEntity;

import com.model.HospitalSlotEntity;
import com.service.BloodDonationService;
import com.service.SlotDetailsService;

@Controller
@RequestMapping("donation")
public class BloodDonationController {

	Logger logger = Logger.getLogger(BloodDonationController.class.getName());
	
	@Autowired
	BloodDonationService blooddonationservice;
	
	@Autowired
	SlotDetailsService slotdetailservice;

	
	@GetMapping("/form")  //It display the form to input Donor details
	public String addRequirementForm(Model model)
	{
		BloodDonationEntity bloodDonationEntity=new BloodDonationEntity();
		model.addAttribute("donatordetails",bloodDonationEntity);
		
		return "donatorInformation";
	}
	
	@PostMapping("/addblooduser")  //It adds the Donor information in the database
	public String addDonator(@ModelAttribute("donatordetails")BloodDonationEntity bloodDonationEntity)
	{
		boolean b =false;
		try
		{
			 b=blooddonationservice.addBloodDonation(bloodDonationEntity);
		}catch (Exception e)
		{
			b=false; 
		}
		
	
		if(b==true)
		    return "redirect:/donation/slotform";
		else
			return "redirect:/donation/form?contactexist";
	}
	
	
	
	@GetMapping("/slotform")  //It displays Slot Booking Form
	public String addSlotForm(Model model)
{
		HospitalSlotEntity hospitalslotentity=new HospitalSlotEntity();
		
		model.addAttribute("donatorslotdetails",hospitalslotentity);
		return "donationSlotBooking";
	}
	
	@PostMapping("/addslot")  //It adds the slot information to the database
	public String addDonator(@RequestParam("hospitalname")String hospital,@RequestParam("city")String city,@RequestParam("date")String date,@RequestParam("time")String time)
	{
		HospitalSlotEntity hospitalslotentity=new HospitalSlotEntity(hospital, city, date, time);
		boolean b =slotdetailservice.BookSlotRequirement(hospitalslotentity);
		if(b==true)
			return "redirect:/donation/slotform?success";
		else
			return "redirect:/donation/slotform?error";
	}
	
	
	
	public BloodDonationController() {
		
	}

}
