package com.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.config.ResourceNotFoundException;
import com.model.UserDetailsEntity;
import com.service.BloodRequirementService;
import com.service.FeedbackService;
import com.service.UserService;


@Controller
public class UserController {

	@Autowired
	UserService userService;
	
	@Autowired
	BloodRequirementService bloodrequirementservice;

	@Autowired
	FeedbackService feedbackService;

	@ExceptionHandler(ResourceNotFoundException.class)
	public String handleResourceNotFoundException() {
	        return "404";
	}
	
@GetMapping("/home")  //It displays the homepage
public String homepage(Model model){
	model.addAttribute("requirementList", bloodrequirementservice.getBloodRequirementList());
	model.addAttribute("feedbacklist",feedbackService.getFeedBackList());
	return "homePage";
}
  
  @GetMapping("/register") //It displays the User Registration Form
  public String userRegistrationForm(Model model, Principal principal) {
    return "userRegistrationForm";
  }
  
  
  
  @PostMapping("/saveDetails")  //It registers the user and save user details in the database
  public String register(Model model,@RequestParam("first") String first,@RequestParam("last") String last,@RequestParam("age") int age,
		  @RequestParam("gender") String gender,@RequestParam("contact") String contact,@RequestParam("email") String email,
		  @RequestParam("password") String password,@RequestParam("weight") int weight,@RequestParam("state") String state,@RequestParam("area") String area,@RequestParam("pincode") int pincode,@RequestParam("bloodgroup") String blood_group) {
	  
	  String encoded=new BCryptPasswordEncoder().encode(password);
	  UserDetailsEntity userReg=new UserDetailsEntity(first,last,age,gender,contact,email,encoded,weight,state,area,pincode,blood_group);
	  boolean flag=false;
	  try{
		   flag=userService.saveUser(userReg);
	  }catch (Exception e) {
		  return "redirect:/register?exist";
	}

	  if(flag==true)
		  return "redirect:/register?success";
	  else
		  return "redirect:/register?fail";
  }
  
  @RequestMapping(value="/logout", method=RequestMethod.GET) //It is used to for user logout 
  public String logoutPage(HttpServletRequest request, HttpServletResponse response) {  
      Authentication auth = SecurityContextHolder.getContext().getAuthentication();  
      if (auth != null){      
         new SecurityContextLogoutHandler().logout(request, response, auth);  
      }  
       return "redirect:/";  
   }  
  
}
