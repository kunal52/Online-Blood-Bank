SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `onlinebloodbankdb` DEFAULT CHARACTER SET utf8 ;
USE `onlinebloodbankdb` ;

-- -----------------------------------------------------
-- Table `onlinebloodbankdb`.`blood_donation`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `onlinebloodbankdb`.`blood_donation` (
  `contact` VARCHAR(10) NOT NULL ,
  `area` VARCHAR(255) NOT NULL ,
  `blood_group` VARCHAR(20) NOT NULL ,
  `pincode` VARCHAR(255) NOT NULL ,
  `state` VARCHAR(255) NOT NULL ,
  PRIMARY KEY (`contact`) )
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `onlinebloodbankdb`.`blood_requirement`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `onlinebloodbankdb`.`blood_requirement` (
  `contact` VARCHAR(10) NOT NULL ,
  `area` VARCHAR(255) NOT NULL ,
  `blood_group` VARCHAR(20) NOT NULL ,
  `pincode` VARCHAR(255) NOT NULL ,
  `state` VARCHAR(255) NOT NULL ,
  PRIMARY KEY (`contact`) )
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `onlinebloodbankdb`.`feedback`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `onlinebloodbankdb`.`feedback` (
  `id` INT(11) NOT NULL ,
  `city` VARCHAR(30) NOT NULL ,
  `feedback` VARCHAR(500) NOT NULL ,
  `hospital` VARCHAR(30) NOT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `onlinebloodbankdb`.`hibernate_sequence`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `onlinebloodbankdb`.`hibernate_sequence` (
  `next_val` BIGINT(20) NULL DEFAULT NULL )
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `onlinebloodbankdb`.`slot_booking`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `onlinebloodbankdb`.`slot_booking` (
  `id` BINARY(255) NOT NULL ,
  `city` VARCHAR(255) NULL DEFAULT NULL ,
  `date` VARCHAR(255) NULL DEFAULT NULL ,
  `hospital_name` VARCHAR(255) NULL DEFAULT NULL ,
  `time` VARCHAR(255) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `onlinebloodbankdb`.`user_details`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `onlinebloodbankdb`.`user_details` (
  `Email` VARCHAR(30) NOT NULL ,
  `Age` INT(11) NOT NULL ,
  `Area` VARCHAR(255) NOT NULL ,
  `Blood_Group` VARCHAR(255) NOT NULL ,
  `Contact_Number` VARCHAR(10) NOT NULL ,
  `First_Name` VARCHAR(50) NOT NULL ,
  `Gender` VARCHAR(255) NOT NULL ,
  `Last_Name` VARCHAR(50) NOT NULL ,
  `Password` VARCHAR(255) NOT NULL ,
  `Pincode` INT(11) NOT NULL ,
  `State` VARCHAR(255) NOT NULL ,
  `Weight` INT(11) NOT NULL ,
  PRIMARY KEY (`Email`) )
ENGINE = MyISAM
DEFAULT CHARACTER SET = utf8;

USE `onlinebloodbankdb` ;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
